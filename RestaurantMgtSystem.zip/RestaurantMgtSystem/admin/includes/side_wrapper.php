<div class="sidebar-wrapper">
            <div class="logo">
                <a href="index.php" class="simple-text">
                    Five Restaurant
                </a>
            </div>

            <ul class="nav">
                <li class="active">
                    <a href="food_list.php">
                        <i class="pe-7s-notebook"></i>
                        <p>Menu List</p>
                    </a>
                </li>
                <li>
                    <a href="food_add.php">
                        <i class="pe-7s-note"></i>
                        <p>Add Menu</p>
                    </a>
                </li>
				
                <li>
                    <a href="orders.php">
                        <i class="pe-7s-note2"></i>
                        <p>Orders</p>
                    </a>
                </li>
                 <li>
                    <a href="payment.php">
                        <i class="pe-7s-cash"></i>
                        <p>Payment</p>
                    </a>
                </li>
				<li>
                    <a href="reservations.php">
                        <i class="pe-7s-map-2"></i>
                        <p>Table Reservations</p>
                    </a>
                </li>
				<!--<li>
                    <a href="#">
                        <i class="pe-7s-news-paper"></i>
                        <p>Gallery</p>
                    </a>
                </li>-->
                
            </ul>
    	</div>
    </div>